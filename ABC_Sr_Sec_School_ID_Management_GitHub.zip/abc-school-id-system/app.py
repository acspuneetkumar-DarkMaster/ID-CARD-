import csv
import io
import os
import secrets
import sqlite3
from functools import wraps
from pathlib import Path
from flask import Flask, Response, abort, flash, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import qrcode

BASE = Path(__file__).resolve().parent
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['MAX_CONTENT_LENGTH'] = 3 * 1024 * 1024
DB = Path(os.environ.get('DATABASE_PATH', str(BASE / 'school.db')))
UPLOADS = BASE / 'static' / 'uploads'
UPLOADS.mkdir(parents=True, exist_ok=True)
SCHOOL = os.environ.get('SCHOOL_NAME', 'ABC Sr Sec School')
FIELDS = ['code', 'name', 'role', 'class_name', 'section', 'guardian', 'phone', 'dob', 'address', 'designation', 'department']

def db():
    connection = sqlite3.connect(DB)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('student','staff')), class_name TEXT, section TEXT, guardian TEXT, phone TEXT, dob TEXT, address TEXT, designation TEXT, department TEXT, photo TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        con.execute('CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password_hash TEXT NOT NULL)')
        if not con.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            password = os.environ.get('ADMIN_PASSWORD')
            if not password:
                raise RuntimeError('Set ADMIN_PASSWORD before starting the application.')
            con.execute('INSERT INTO users VALUES (?, ?)', ('admin', generate_password_hash(password)))

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get('user'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_school():
    return {'school': SCHOOL}

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        with db() as con:
            user = con.execute('SELECT * FROM users WHERE username=?', (request.form.get('username'),)).fetchone()
        if user and check_password_hash(user['password_hash'], request.form.get('password', '')):
            session.clear()
            session['user'] = user['username']
            return redirect(url_for('index'))
        flash('Invalid login credentials.', 'error')
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
@login_required
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    q = request.args.get('q', '').strip()
    role = request.args.get('role', '')
    sql = 'SELECT * FROM people WHERE 1=1'
    args = []
    if q:
        sql += ' AND (name LIKE ? OR code LIKE ? OR class_name LIKE ?)'
        args += [f'%{q}%'] * 3
    if role in ('student', 'staff'):
        sql += ' AND role=?'
        args.append(role)
    sql += ' ORDER BY id DESC'
    with db() as con:
        people = con.execute(sql, args).fetchall()
        count = con.execute('SELECT role, COUNT(*) n FROM people GROUP BY role').fetchall()
    return render_template('index.html', people=people, counts={r['role']: r['n'] for r in count}, q=q, role=role)

def photo_upload(old=None):
    file = request.files.get('photo')
    if not file or not file.filename:
        return old
    ext = Path(secure_filename(file.filename)).suffix.lower()
    if ext not in ('.jpg', '.jpeg', '.png', '.webp'):
        raise ValueError('Photo must be JPG, PNG or WEBP.')
    from PIL import Image
    file.stream.seek(0)
    image = Image.open(file.stream)
    image.verify()
    file.stream.seek(0)
    image = Image.open(file.stream).convert('RGB')
    image.thumbnail((800, 800))
    name = secrets.token_hex(16) + '.jpg'
    image.save(UPLOADS / name, format='JPEG', quality=85)
    return name

@app.route('/new', methods=['GET', 'POST'])
@login_required
def create():
    if request.method == 'POST':
        try:
            data = [request.form.get(k, '').strip() for k in FIELDS]
            if not data[0] or not data[1] or data[2] not in ('student', 'staff'):
                raise ValueError('ID, name and valid role are required.')
            photo = photo_upload()
            with db() as con:
                con.execute(f"INSERT INTO people ({','.join(FIELDS)},photo) VALUES ({','.join('?' for _ in range(len(FIELDS)+1))})", data + [photo])
            flash('Record added.', 'success')
            return redirect(url_for('index'))
        except (ValueError, sqlite3.IntegrityError) as e:
            flash(str(e), 'error')
    return render_template('form.html', person=None)

@app.route('/edit/<int:pid>', methods=['GET', 'POST'])
@login_required
def edit(pid):
    with db() as con:
        person = con.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone()
    if not person:
        abort(404)
    if request.method == 'POST':
        try:
            data = [request.form.get(k, '').strip() for k in FIELDS]
            if not data[0] or not data[1] or data[2] not in ('student', 'staff'):
                raise ValueError('ID, name and valid role are required.')
            photo = photo_upload(person['photo'])
            with db() as con:
                con.execute(f"UPDATE people SET {','.join(k+'=?' for k in FIELDS)},photo=? WHERE id=?", data + [photo, pid])
            flash('Record updated.', 'success')
            return redirect(url_for('index'))
        except (ValueError, sqlite3.IntegrityError) as e:
            flash(str(e), 'error')
    return render_template('form.html', person=person)

@app.route('/delete/<int:pid>', methods=['POST'])
@login_required
def delete(pid):
    with db() as con:
        con.execute('DELETE FROM people WHERE id=?', (pid,))
    flash('Record deleted.', 'success')
    return redirect(url_for('index'))

@app.route('/card/<int:pid>')
@login_required
def card(pid):
    with db() as con:
        person = con.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone()
    if not person:
        abort(404)
    return render_template('card.html', person=person)

@app.route('/qr/<int:pid>')
@login_required
def qr(pid):
    with db() as con:
        person = con.execute('SELECT code, name, role FROM people WHERE id=?', (pid,)).fetchone()
    if not person:
        abort(404)
    # QR deliberately contains no private contact or address details.
    img = qrcode.make(f"{SCHOOL}\nID: {person['code']}\nName: {person['name']}\nRole: {person['role']}")
    output = io.BytesIO()
    img.save(output, format='PNG')
    return Response(output.getvalue(), mimetype='image/png')

@app.route('/import', methods=['POST'])
@login_required
def import_csv():
    file = request.files.get('csv')
    if not file:
        flash('Select a CSV file.', 'error')
        return redirect(url_for('index'))
    try:
        reader = csv.DictReader(io.StringIO(file.read().decode('utf-8-sig')))
        if not reader.fieldnames or not {'code', 'name', 'role'}.issubset(reader.fieldnames):
            raise ValueError('CSV must include code,name,role columns.')
        rows = []
        for row in reader:
            values = [(row.get(k) or '').strip() for k in FIELDS]
            if not values[0] or not values[1] or values[2] not in ('student', 'staff'):
                raise ValueError('Each row requires code, name and student/staff role.')
            rows.append(values)
        with db() as con:
            con.executemany(f"INSERT INTO people ({','.join(FIELDS)}) VALUES ({','.join('?' for _ in FIELDS)})", rows)
        flash(f'Imported {len(rows)} records.', 'success')
    except (ValueError, UnicodeDecodeError, sqlite3.IntegrityError) as e:
        flash(f'Import failed: {e}', 'error')
    return redirect(url_for('index'))

@app.route('/export')
@login_required
def export_csv():
    with db() as con:
        rows = con.execute(f"SELECT {','.join(FIELDS)} FROM people ORDER BY id").fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(FIELDS)
    writer.writerows([r[k] for k in FIELDS] for r in rows)
    return Response('\ufeff' + out.getvalue(), mimetype='text/csv', headers={'Content-Disposition': 'attachment; filename=school_records.csv'})

@app.route('/print-all')
@login_required
def print_all():
    with db() as con:
        people = con.execute('SELECT * FROM people ORDER BY class_name, name').fetchall()
    return render_template('print_all.html', people=people)

@app.route('/uploads/<name>')
@login_required
def uploaded(name):
    return send_from_directory(UPLOADS, name)

if __name__ == '__main__':
    init_db()
    app.run(host='127.0.0.1', port=5000, debug=False)
